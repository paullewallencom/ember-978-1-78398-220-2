import Ember from 'ember';

export default Ember.Component.extend({
	name: 'Erik',
	grade: 12,
	nickName: 'E',

});
