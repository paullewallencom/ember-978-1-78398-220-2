import clean from '../../../utils/clean';
import { module, test } from 'qunit';

module('Unit | Utility | clean');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = clean();
  assert.ok(result);
});
