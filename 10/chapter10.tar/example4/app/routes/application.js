import Ember from 'ember';
//import d3 from '/bower_components/d3/d3';

export default Ember.Route.extend({

});
