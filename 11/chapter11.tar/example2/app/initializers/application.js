export function initialize( application ) {
	alert('loading application');
}

export default {
  name: 'application',
  initialize
};
