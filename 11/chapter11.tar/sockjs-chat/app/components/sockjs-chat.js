export { default } from 'sockjs-chat/components/sockjs-chat';
