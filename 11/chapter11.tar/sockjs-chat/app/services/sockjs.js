export { default } from 'sockjs-chat/services/sockjs';
