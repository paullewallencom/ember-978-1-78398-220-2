import Ember from 'ember';

export default Ember.Controller.extend({
	prop1: 'foo property'
});
