import { addone } from '../../../helpers/addone';
import { module, test } from 'qunit';

module('Unit | Helper | addone');

// Replace this with your real tests.
test('it works', function(assert) {
  var result = addone(42);
  assert.ok(result);
});
