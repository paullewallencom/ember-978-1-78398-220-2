export default [
    {id: 1, subject: 'History',instructor:[1]},
    {id: 2, subject: 'Spanish',instructor:[1]},
    {id: 3, subject: 'Government',instructor:[3]},
    {id: 4, subject: 'English',instructor:[2]},
    {id: 5, subject: 'German',instructor:[2]},
    {id: 6, subject: 'Social Studies',instructor:[4]},
    {id: 7, subject: 'Math',instructor:[]}
];
