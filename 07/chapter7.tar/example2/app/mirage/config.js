export default function() {
	
	this.get('api/v1/students');

}
