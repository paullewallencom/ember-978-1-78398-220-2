export default [  
    {id: 1, name: 'John', age: 17,school_name: 'School1'},
    {id: 2, name: 'Jack', age: 18,school_name: 'School2'},
    {id: 3, name: 'Suze', age: 17,school_name: 'School3'},
    {id: 4, name: 'Jane', age: 18,school_name: 'School4'}
];
