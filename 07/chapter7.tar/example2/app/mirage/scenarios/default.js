export default function(server ) {
	server.loadFixtures();

}
