export default function( server ) {

  server.createList('book',10);
}
