import Ember from 'ember';

export default Ember.Object.extend({
	homeroom: "",
	age: "",
	gradeTeaching: ""

});
