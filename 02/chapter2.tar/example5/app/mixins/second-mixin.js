import Ember from 'ember';

export default Ember.Mixin.create({
	secondProperty: 'This is the second mixin property';
});
