export default function() {

this.get('/students');
this.get('/students/:id');
}

