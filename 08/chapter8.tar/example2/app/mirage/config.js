export default function() {


    this.get('/schools');
}
