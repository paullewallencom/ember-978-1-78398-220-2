export default function( server ) {


   server.createList('school', 2);
}
