// app/controllers/index.js
import Ember from 'ember';
export default Ember.Controller.extend({
  url: 'http://placehold.it/350x200',
  sideClass:'cc',
  secondClass: 'dd'
});

