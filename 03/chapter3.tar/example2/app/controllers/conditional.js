import Ember from 'ember';

export default Ember.Controller.extend({
	isHomeworkDone: true,
	isChoresDone: true
});
