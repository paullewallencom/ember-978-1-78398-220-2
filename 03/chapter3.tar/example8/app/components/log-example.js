import Ember from 'ember';

export default Ember.Component.extend({
	    helloText: 'Hello World'
});
