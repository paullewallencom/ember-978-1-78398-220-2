import Ember from 'ember';

export default Ember.Component.extend({
	firstName: 'John',
	lastName: 'Smith'
});
