import Ember from 'ember';

export default Ember.Controller.extend({
	students: [ {name: 'Erik'}, {name: 'Jim'}, {name: 'Jane'}]
});
